import { createBrowserRouter } from "react-router-dom";
import HeaderComp from "./commoncomp/header"
import HomeComp from "./Home"
import About from "./About.jsx"
import Example from "./Example.jsx"
import React,{ Suspense }from "react";


const ClassCompoRoute = React.lazy(() => import('./component/ClassComponent/ClassCompoRoute'))
const FunctionalCompoRoute = React.lazy(() => import('./component/Functional Component/FunctionalCompoRoute'))
const MainRouter = createBrowserRouter([
  {
    path: "/",
    element: <><HeaderComp /><HomeComp /></>,
  },
  {
    path: "/about",
    element: <><HeaderComp /><About /></>,
  },
  {
    path: "/example",
    element: <><HeaderComp /><Example /></>,
    children: [
      {
        path: "classcompo/*",
        element: <Suspense fallback={<h2>Loading....</h2> }><ClassCompoRoute/></Suspense>,
      },
      {
        path: "functionalcompo/*",
        element: <Suspense fallback={<h2>Loading....</h2> }><FunctionalCompoRoute/></Suspense>,
      },
    ]
  },
]);

export default MainRouter;