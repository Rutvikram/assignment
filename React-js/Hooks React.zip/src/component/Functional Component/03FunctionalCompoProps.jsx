import React from 'react';
import PropsChild from './04Props';


const FunctionalCompoProps = () => {
    return (
        <>
          <h1 className='text-center'>Props</h1>  
          <p>Parent Componnent</p>
          <PropsChild  title="Data Some"  />

        </>
    );
};

export default FunctionalCompoProps;