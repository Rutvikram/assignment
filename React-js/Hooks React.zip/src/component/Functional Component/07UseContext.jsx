import React from 'react';

const UseContext = () => {
    return (
        <>
            <h1>useContext</h1>
            <p>useContext returns the context value for the context you passed. To determine the 
                contextvalue, React searches the component tree and finds the closest context
                  provider abovefor that particular context.</p>

        </>
    );
};

export default UseContext;