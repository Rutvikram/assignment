import React from 'react';
import {Link, Outlet} from "react-router-dom";

const ClassCompoMenu = () => {
    return (
        <>
            <ul>
                <li><Link to="functionalcompointro"> Functional Component Intro </Link></li>
                <li><Link to="functionalcompostate"> Functional Component State </Link></li>
                <li><Link to="functionalcompoprops"> Functional Component Props </Link></li>
                <li><Link to="functionalcompousememo"> Functional Component useMemo </Link></li>
                <li><Link to="functionalcompousecallback"> Functional Component useCallback </Link></li>
                <li><Link to="functionalcompouseeffect"> Functional Component useEffect </Link></li>
                <li><Link to="functionalcompouseleyouteffect"> Functional Component useLeyoutEffect </Link></li>
                <li><Link to="functionalcompousecontext"> Functional Component useContext </Link></li>
            </ul>
            <Outlet></Outlet>
        </>
    );
};

export default ClassCompoMenu;