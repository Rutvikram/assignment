import React from 'react';

const FunctionalCompoIntro = () => {
    return (
        <div>
            functional component intro
        </div>
    );
};

export default FunctionalCompoIntro;