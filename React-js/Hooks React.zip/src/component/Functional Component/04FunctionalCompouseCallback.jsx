import React, { useState, useCallback } from "react";


var funccount = new Set();
const App = () => {
    const [count, setCount] = useState(0);
    const [number, setNumber] = useState(0);

    const incrementCounter = useCallback(() => {
        setCount(count + 1);
    }, [count]);
    const decrementCounter = useCallback(() => {
        setCount(count - 1);
    }, [count]);
    const incrementNumber = useCallback(() => {
        setNumber(number + 1);
    }, [number]);
    const decrementNumber = useCallback(() => {
        setNumber(number - 1);
    }, [number]);

    funccount.add(incrementCounter);
    funccount.add(decrementCounter);
    funccount.add(incrementNumber);
    funccount.add(decrementNumber);
    console.log(funccount.size);

    return (
        <div>
            <div>
                <p>useCallback Hooks returns a memorized function</p>
                <p>useCallback is a React Hook that lets you cache a function definition between re-renders.</p>
                Count: {count}
                <br />
                Number: {number}
            </div>
            <button className="btn" onClick={incrementCounter}>Increase counter</button>
            <button className="btn" onClick={decrementCounter}>Decrease Counter</button>
            <button className="btn" onClick={incrementNumber}>increase number</button>
            <button className="btn" onClick={decrementNumber}>increase number</button>
        </div>
    );
};

export default App;