import React, { useEffect, useLayoutEffect, useState } from 'react';

const FunctionalCompoUseEffect = () => {
    const [counter,setCounter] = useState(0)
    const [otherdata,setOtherData] = useState("something")
    useLayoutEffect(()=>{
        console.log("useEffect called as construct");
        return ()=>{
            console.log("Call As a Didmount");
        };
    },[otherdata])
    // useLayoutEffect(()=>{
    //     console.log("useLayoutEffect called as const");
    // },[])
    useEffect(()=>{
        console.log("useEffect called");
    },[counter])
    const increment = ()=>{
        console.log("btn clicked");
        setCounter(counter+1);
    };
    return (
        <>
            Functional Compo UseEffect <br />
            <button className='btn' onClick={increment}>Click {counter}</button> <br />
            <button className='btn' onClick={()=>{ console.log("called"); setOtherData("testing")}}>Test Other Data {otherdata}</button>
        </>
    );
};

export default FunctionalCompoUseEffect;