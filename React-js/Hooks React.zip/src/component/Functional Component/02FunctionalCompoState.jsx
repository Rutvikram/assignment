import React from 'react';
import { useState } from 'react';

const FunctionalCompoState = () => {
    const [state,setState] = useState("state Data");
    const [coounter,setCounter] = useState(0);
    // const UserName = "Testing"
    let UserName = "Testing"
    const increase = ()=>{
        // console.log("calld increse");
        setCounter(coounter+1);
    };

    const changedata = ()=>{
        // console.log("calld");
        UserName = "Something"
        setState("setState data");
    };

    return (
        <>

        <h1 className='text-center'>State</h1>
            <p>User Name : {UserName}</p>
            <p>State Data : {state}</p>
            <button className='btn' onClick={changedata}>Click</button>
            <p>State Data : {coounter}</p>
            <button className='btn' onClick={increase}>Click</button>
        </>
    );
};

export default FunctionalCompoState;