import React, { useMemo, useState } from 'react';

const FunctionalCompouseMemo = () => {
    const [wordindex, setWordindex] = useState(0);
    const words = ["hey","how","are","your","what","hey","how","are","your"];
    const word = words[wordindex];
    const computeLetterCount = (word) => {
        console.log("computeLetterCount",word);
        let i = 0;  
        while (i < 100000) i++;
        return word.length; 
    };
    const letterCount = useMemo(()=>computeLetterCount(word),[]);
    return (
        <>
        <p>"{word}" has {letterCount} letters </p>
        {computeLetterCount(wordindex)}
            <button className='btn' onClick={() => {
                console.log("call btn click");
                {
                    if (wordindex + 1 === words.length) { setWordindex(0) }
                     else { setWordindex(wordindex + 1) }
                };
            }}>Click</button>
            <br />
            <br />
            next word{wordindex}
        </>
    );
};

export default FunctionalCompouseMemo;