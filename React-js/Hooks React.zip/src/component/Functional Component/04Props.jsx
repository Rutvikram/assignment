import React from 'react';

const Props = (Props) => {
    return (
        <>
          <h3> Props Child</h3>  
          {Props.title}
        </>
    );
};

export default Props;