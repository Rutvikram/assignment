import React from 'react';
import { Route, Routes } from 'react-router-dom';
import FunctionalCompoMenu from './FunctionalCompoMenu.jsx';
import FunctionalCompoIntro from './01FunctionalCompoIntro.jsx';
import FunctionalCompoState from './02FunctionalCompoState.jsx';
import FunctionalCompoProps from './03FunctionalCompoProps.jsx';
import FunctionalCompouseMemo from './04FunctionalCompouseMemo.jsx';
import FunctionalCompouseCallback from './04FunctionalCompouseCallback.jsx';
import FunctionalCompouseEffect from './05FunctionalCompouseEffect.jsx';
import FunctionalCompouseLeyoutEffect from './06FunctionalCompouseLeyoutEffect.jsx';
import FunctionalCompouseContext from './07UseContext.jsx';

const functionalCompoRoute = () => {
   
        return (
            <>
              <Routes>
                <Route path="/" element={<FunctionalCompoMenu/>} >
                <Route path="functionalcompointro" element={< FunctionalCompoIntro/>} />   
                <Route path="functionalcompostate" element={< FunctionalCompoState/>} />   
                <Route path="functionalcompoprops" element={< FunctionalCompoProps/>} />   
                <Route path="functionalcompousememo" element={< FunctionalCompouseMemo/>} />   
                <Route path="functionalcompousecallback" element={< FunctionalCompouseCallback/>} />   
                <Route path="functionalcompouseeffect" element={< FunctionalCompouseEffect/>} />   
                <Route path="functionalcompouseleyouteffect" element={< FunctionalCompouseLeyoutEffect/>} />   
                <Route path="functionalcompousecontext" element={< FunctionalCompouseContext/>} />   
                </Route>
              </Routes>    
            </>
        );
    }


export default functionalCompoRoute;