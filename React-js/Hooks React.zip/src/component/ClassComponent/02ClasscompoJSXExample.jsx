import React, { Component } from 'react';

class ClasscompoJSXExample extends Component {
    render() {
        let a = 50;
        let b = 49;
        return (
            <>
               <h2> JSX Example </h2>
                <p>value of a is {a}</p>                    
                <p>value of b is {b}</p>                    
                <input type="text" value={a+b} />
            </>
        );
    }
}

export default ClasscompoJSXExample;