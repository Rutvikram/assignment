import React, { Component } from 'react';
import CustomCard from './04CustomCardStructure.jsx';

class ClasscompoPropsExample extends Component {
    render() {
        return (
            <>
            <div className="row">
                <div className="col-md-3"><CustomCard imgurl="iphone-14.jfif" title="Product 1" /></div>
                <div className="col-md-3"><CustomCard imgurl= "iphone-14-pro.jfif" title="Product 2" /></div>
                <div className="col-md-3"><CustomCard imgurl="iphone-14.jfif" title="Product 3" /></div>
                <div className="col-md-3"><CustomCard imgurl="iphone-14-pro.jfif" title="Product 4" /></div>
            </div>
            </>
        );
    }
}

export default ClasscompoPropsExample;