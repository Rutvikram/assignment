import React, { Component } from 'react';
import { Route, Routes } from 'react-router-dom';
import ClassCompoMenu from './ClassCompoMenu.jsx';
import ClasscompoIntro from './01classcompointro.jsx';
import ClasscompoJSXExample from './02ClasscompoJSXExample.jsx';
import ClasscompoPropsExample from './03ClasscompoPropsExample.jsx';
import ClasscompoStateExample from './04ClasscompoStateExample.jsx';
import ClasscompoSlider from './05ClasscompoSlider.jsx';

class ClassCompoRoute extends Component {
    render() {
        return (
            <>
              <Routes>
                <Route path="/" element={<ClassCompoMenu/>} >
                <Route path="classcompointro" element={< ClasscompoIntro/>} />
                <Route path="jsxexampleclass" element={< ClasscompoJSXExample/>} />
                <Route path="propsexample" element={<ClasscompoPropsExample/>} />
                <Route path="stateexample" element={<ClasscompoStateExample/>} />
                <Route path="sliderexample" element={<ClasscompoSlider/>} />
                    
                </Route>
              </Routes>    
            </>
        );
    }
}

export default ClassCompoRoute;