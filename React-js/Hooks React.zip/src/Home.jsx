import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
            <div>
                Home page data
            </div>
        );
    }
}

export default Home;