import React, { Component } from 'react';

class classcompointro extends Component {
    render() {
        return (
            <>  Class Component Introduction 
            </>
        );
    }
}

export default classcompointro;