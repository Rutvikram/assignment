import React, { Component } from 'react';
import {Routes,Route} from 'react-router-dom';
import ClassCompoMenu from './ClassCompoMenu.jsx';
import ClassCompoIntro from './01classcompointro';
import ClassCompoJSXExmaple from './02ClassCompoJSXExmaple';
import ClassCompoPropsExmaple from './03ClassCompoPropsExmaple';

class ClassCompoRouter extends Component {
    render() {
        return (
            <>
                <Routes>
                    <Route path="/" element={<ClassCompoMenu/>} >
                        <Route path="classcompointro" element={<ClassCompoIntro />} />
                        <Route path="jsxexampleclass" element={<ClassCompoJSXExmaple />} />
                        <Route path="propsexample" element={<ClassCompoPropsExmaple />} />
                    </Route>
                </Routes>  
            </>
        );
    }
}

export default ClassCompoRouter;