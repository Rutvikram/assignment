import React, { Component } from 'react';
import { Link ,Outlet} from 'react-router-dom';

class ClassCompoMenu extends Component {
    render() {
        return (
            <>
              <ul>
                <li><Link to="classcompointro">classcompointro</Link></li>
                <li><Link to="jsxexampleclass">Class Compo JSX</Link></li>
                <li><Link to="propsexample">Class Compo Props</Link></li>
              </ul>
            <Outlet></Outlet>  
            </>
        );
    }
}

export default ClassCompoMenu;