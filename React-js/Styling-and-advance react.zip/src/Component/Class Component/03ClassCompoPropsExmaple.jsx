import React, { Component } from 'react';
import CustomCard from './04CustomCardStruct';


class ClassCompoPropsExmaple extends Component {
    render() {
        return (
            <>
                <div className="row">
                    <div className="col-md-3 "><CustomCard imgurl="i-Phone-13.webp" title="Product-1"/></div>
                    <div className="col-md-3"><CustomCard imgurl="i-Phone-12.webp" title="Product-2"/></div>
                    <div className="col-md-3"><CustomCard imgurl="i-Phone-13.webp" title="Product-3"/></div>
                    <div className="col-md-3"><CustomCard imgurl="i-Phone-14.webp" title="Product-4"/></div>
                </div>
            </>
        );
    }
}

export default ClassCompoPropsExmaple;