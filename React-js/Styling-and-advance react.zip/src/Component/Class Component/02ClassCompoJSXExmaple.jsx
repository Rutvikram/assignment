import React, { Component } from 'react';

class ClassCompoJSXExmaple extends Component {
    render() {
        let a = 50;
        let b = 70;
        return (
            <>
              <h2>JSX</h2>  
              <p>value of a is {a}</p>
              <p>value of a is {b}</p>
              <p>adition of a and b is {a+b}</p>
              <input type="text" value={a+b} />
            </>
        );
    }
}

export default ClassCompoJSXExmaple;