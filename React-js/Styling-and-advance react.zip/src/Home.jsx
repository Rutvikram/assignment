import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
            <div>
                Home Page Data
            </div>
        );
    }
}

export default Home;