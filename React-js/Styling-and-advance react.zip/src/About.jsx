import React, { Component } from 'react';
class About extends Component {
    render() {
        return (
            <>
                
                <h2>About Page Data</h2>
            </>
        );
    }
}

export default About;