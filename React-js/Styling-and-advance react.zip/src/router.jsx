import React, { Suspense } from 'react';
import {createBrowserRouter,Outlet} from "react-router-dom";
import HeaderComp from './commonComp/header';
import HomeComp from './Home';
import About from './About';
import Example from './Example';




const ClassCompoRoute = React.lazy(()=> (import('./Component/Class Component/ClassCompoRouter')))
// const ClassCompoRoute = React.lazy(() => import('./Component/Class Component/ClassCompoRouter'))
const MainRouter = createBrowserRouter([
  {
    path: "/",
    element: <><HeaderComp/><HomeComp/></>,
  },
  {
    path: "/About",
    element: <><HeaderComp/><About/></>,
  },
  
  {
    path: "/Example",
    element: <><HeaderComp/><Example/></>,
    children :[
      {
          path: "classcompo/*",
          element: <Suspense fallback={<h2>Ruko Jara Sabar Karo.....</h2>}><ClassCompoRoute/> </Suspense>, 
          // children:<></>
      }
    ]
  },
]);

export default MainRouter; 