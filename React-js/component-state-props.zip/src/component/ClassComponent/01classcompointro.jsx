import React, { Component } from 'react';

class classcompointro extends Component {
    render() {
        return (
            <div>
                Welcome
            </div>
        );
    }
}

export default classcompointro;