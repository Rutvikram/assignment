import React, { Component } from 'react';
import {Link, Outlet} from "react-router-dom";
class ClassCompoMenu extends Component {
    render() {
        return (
            <>
                <ul>
                    <li><Link to="classcompointro"> Class Comp Intro </Link></li>
                    <li><Link to="jsxexampleclass"> Class Comp JSX </Link></li>
                    <li><Link to="propsexample"> Class Compo Props </Link></li>
                    <li><Link to="stateexample"> Class Compo State </Link></li>
                    <li><Link to="sliderexample"> Class Compo Slider </Link></li>
                </ul>
                <Outlet></Outlet>
            </>
        );
    }
}

export default ClassCompoMenu;