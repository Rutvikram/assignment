import React from 'react';
import {Link, Outlet} from "react-router-dom";

const ClassCompoMenu = () => {
    return (
        <>
            <ul>
                <li><Link to="functionalcompointro"> Functional Component Intro </Link></li>
            </ul>
            <Outlet></Outlet>
        </>
    );
};

export default ClassCompoMenu;