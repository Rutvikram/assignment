import React from 'react';
import { Route, Routes } from 'react-router-dom';
import FunctionalCompoMenu from './FunctionalCompoMenu.jsx';
import FunctionalCompoIntro from './01FunctionalCompoIntro.jsx';

const functionalCompoRoute = () => {
   
        return (
            <>
              <Routes>
                <Route path="/" element={<FunctionalCompoMenu/>} >
                <Route path="functionalcompointro" element={< FunctionalCompoIntro/>} />   
                </Route>
              </Routes>    
            </>
        );
    }


export default functionalCompoRoute;