import React, { Component } from 'react';

class ComponentExample extends Component {
    render() {
        return (
            <div>
                Testing
            </div>
        );
    }
}

export default ComponentExample;