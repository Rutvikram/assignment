import { createBrowserRouter } from "react-router-dom";
import HeaderComp from "./commoncomp/header"
import HomeComp from "./Home"
import About from "./About.jsx"
import Example from "./Example.jsx"
import React,{ Suspense }from "react";


const ClassCompoRoute = React.lazy(() => import('./component/Class Component/ClassCompoRoute'))
const MainRouter = createBrowserRouter([
  {
    path: "/",
    element: <><HeaderComp /><HomeComp /></>,
  },
  {
    path: "/about",
    element: <><HeaderComp /><About /></>,
  },
  {
    path: "/example",
    element: <><HeaderComp /><Example /></>,
    children: [
      {
        path: "classcompo/*",
        element: <Suspense fallback={<h2>Loading....</h2> }><ClassCompoRoute/></Suspense>,
      },
    ]
  },
]);

export default MainRouter;