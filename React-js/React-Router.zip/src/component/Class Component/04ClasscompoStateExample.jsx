import React, { Component } from 'react';

class ClasscompoStateExample extends Component {
    btnClickHandel(){
        console.log("Call");
    }
    render() {
        return (
            <div>
                <button className='btn' onClick={this.btnClickHandel}>Click</button>
            </div>
        );
    }
}

export default ClasscompoStateExample;